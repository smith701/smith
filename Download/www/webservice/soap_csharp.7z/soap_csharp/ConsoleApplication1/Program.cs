﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Web.Services;
using System.Web.UI;
using System.Web.Configuration;

namespace ConsoleApplication1
{
    class Program
    {
        static bool RemoteCertificateValidationCallback(Object sender,
        X509Certificate certificate,
        X509Chain chain,
        SslPolicyErrors sslPolicyErrors)
        {
            // Always accept
            return true;
        }


        static public string EncodeTo64(string toEncode)
        {
            byte[] toEncodeAsBytes = System.Text.ASCIIEncoding.ASCII.GetBytes(toEncode);

            string returnValue = System.Convert.ToBase64String(toEncodeAsBytes);

            return returnValue;

        }

        static void Main(string[] args)
        {
        string[] SoapResult;
        int i;

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls;
            ServicePointManager.ServerCertificateValidationCallback = RemoteCertificateValidationCallback;
            WebserviceMSFService server = new WebserviceMSFService();

            // Instanciation du Web Service et de la session
            server.CookieContainer = new System.Net.CookieContainer();

            //*******************************************************************
            //*******************************************************************
            if (false) //set to true if you want to test
            {
                SoapResult = server.getHelloWorld();
                for (i = 0; i < SoapResult.Length; i++)
                    Console.WriteLine("Resultat :" + SoapResult[i]);
            }

            //*******************************************************************
            //*******************************************************************
            SoapResult = server.login("xxx", "xxx");
            for (i = 0; i < SoapResult.Length; i++)
                Console.WriteLine("Resultat :" + SoapResult[i]);


            //*******************************************************************
            //*******************************************************************
            if (false)  //set to true if you want to test
            {
                SoapResult = server.status("249765.msf01");
                for (i = 0; i < SoapResult.Length; i++)
                    Console.WriteLine("Resultat :" + SoapResult[i]);
            }

            //*******************************************************************
            //*******************************************************************
            SoapResult = server.upload("test.wav", EncodeTo64("opiopiopopipoiop"));
            for (i = 0; i < SoapResult.Length; i++)
                Console.WriteLine("Resultat :" + SoapResult[i]);


            Console.WriteLine("FIN" );
        }
    }
}


/*            CookieCollection CookieList = new CookieCollection();
            CookieList = server.CookieContainer.GetCookies(new Uri("https://mediaspeech.com"));

            Cookie MyCookie = new Cookie();
            MyCookie = CookieList["PHPSESSID"];*/
